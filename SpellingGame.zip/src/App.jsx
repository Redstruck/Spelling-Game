import SpellingGame from './SpellingGame.jsx';

function App() {
  return (
    <div className="App">
      <SpellingGame />
    </div>
  );
}

export default App;